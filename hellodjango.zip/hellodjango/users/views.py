from django.http import JsonResponse
from django.core.serializers import serialize
import json
from random import sample
from .models import (
    ActionMovie, AdventureMovie, ThrillerMovie, ComedyMovie, 
    FantasyMovie, ScienceFictionMovie, RomanceMovie, 
    CrimeMovie, DramaMovie, HorrorMovie,
    HipHopMusic, PopMusic, BollywoodMusic, CountryMusic, ClassicalMusic,
    ActionGame, RPGGame, SimulationGame, AdventureGame, SportsGame,
    Book, Course, Hobby, Relax
)

# Helper function to get random items from a given model
def get_random_items(model, count=5):
    all_ids = list(model.objects.values_list('id', flat=True))
    if len(all_ids) <= count:
        random_ids = all_ids
    else:
        random_ids = sample(all_ids, count)
    random_items = model.objects.filter(id__in=random_ids)
    return json.loads(serialize('json', random_items))

# Views for movies
def action_movie_list(request):
    items = get_random_items(ActionMovie)
    return JsonResponse(items, safe=False)

def adventure_movie_list(request):
    items = get_random_items(AdventureMovie)
    return JsonResponse(items, safe=False)

def thriller_movie_list(request):
    items = get_random_items(ThrillerMovie)
    return JsonResponse(items, safe=False)

def comedy_movie_list(request):
    items = get_random_items(ComedyMovie)
    return JsonResponse(items, safe=False)

def fantasy_movie_list(request):
    items = get_random_items(FantasyMovie)
    return JsonResponse(items, safe=False)

def science_fiction_movie_list(request):
    items = get_random_items(ScienceFictionMovie)
    return JsonResponse(items, safe=False)

def romance_movie_list(request):
    items = get_random_items(RomanceMovie)
    return JsonResponse(items, safe=False)

def crime_movie_list(request):
    items = get_random_items(CrimeMovie)
    return JsonResponse(items, safe=False)

def drama_movie_list(request):
    items = get_random_items(DramaMovie)
    return JsonResponse(items, safe=False)

def horror_movie_list(request):
    items = get_random_items(HorrorMovie)
    return JsonResponse(items, safe=False)

# Views for games
def action_game_list(request):
    items = get_random_items(ActionGame)
    return JsonResponse(items, safe=False)

def rpg_game_list(request):
    items = get_random_items(RPGGame)
    return JsonResponse(items, safe=False)

def simulation_game_list(request):
    items = get_random_items(SimulationGame)
    return JsonResponse(items, safe=False)

def adventure_game_list(request):
    items = get_random_items(AdventureGame)
    return JsonResponse(items, safe=False)

def sports_game_list(request):
    items = get_random_items(SportsGame)
    return JsonResponse(items, safe=False)

# Views for music
def hiphop_song_list(request):
    items = get_random_items(HipHopMusic)
    return JsonResponse(items, safe=False)

def pop_song_list(request):
    items = get_random_items(PopMusic)
    return JsonResponse(items, safe=False)

def bollywood_song_list(request):
    items = get_random_items(BollywoodMusic)
    return JsonResponse(items, safe=False)

def country_song_list(request):
    items = get_random_items(CountryMusic)
    return JsonResponse(items, safe=False)

def classical_song_list(request):
    items = get_random_items(ClassicalMusic)
    return JsonResponse(items, safe=False)

# Views for books and courses
def top_books(request):
    items = get_random_items(Book)
    return JsonResponse(items, safe=False)

def tech_courses(request):
    items = get_random_items(Course.objects.filter(category='Tech'))
    return JsonResponse(items, safe=False)

def language_courses(request):
    items = get_random_items(Course.objects.filter(category='Language'))
    return JsonResponse(items, safe=False)

def digital_marketing_courses(request):
    items = get_random_items(Course.objects.filter(category='Digital Marketing'))
    return JsonResponse(items, safe=False)

def drop_shipping_courses(request):
    items = get_random_items(Course.objects.filter(category='Drop Shipping'))
    return JsonResponse(items, safe=False)

# Views for hobbies and relaxation activities
def hobby_list(request):
    items = get_random_items(Hobby)
    return JsonResponse(items, safe=False)

def relax_list(request):
    items = get_random_items(Relax)
    return JsonResponse(items, safe=False)
