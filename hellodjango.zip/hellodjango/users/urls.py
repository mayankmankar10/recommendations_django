from django.urls import path
from . import views

urlpatterns = [
    path('movies/action-movies/', views.action_movie_list, name='action_movie_list'),
    path('movies/adventure-movies/', views.adventure_movie_list, name='adventure_movie_list'),
    path('movies/thriller-movies/', views.thriller_movie_list, name='thriller_movie_list'),
    path('movies/comedy-movies/', views.comedy_movie_list, name='comedy_movie_list'),
    path('movies/fantasy-movies/', views.fantasy_movie_list, name='fantasy_movie_list'),
    path('movies/science-fiction-movies/', views.science_fiction_movie_list, name='science_fiction_movie_list'),
    path('movies/romance-movies/', views.romance_movie_list, name='romance_movie_list'),
    path('movies/crime-movies/', views.crime_movie_list, name='crime_movie_list'),
    path('movies/drama-movies/', views.drama_movie_list, name='drama_movie_list'),
    path('movies/horror-movies/', views.horror_movie_list, name='horror_movie_list'),
    
    path('games/action-games/', views.action_game_list, name='action_game_list'),
    path('games/rpg-games/', views.rpg_game_list, name='rpg_game_list'),
    path('games/simulation-games/', views.simulation_game_list, name='simulation_game_list'),
    path('games/adventure-games/', views.adventure_game_list, name='adventure_game_list'),
    path('games/sports-games/', views.sports_game_list, name='sports_game_list'),
    
    path('music/hiphop-songs/', views.hiphop_song_list, name='hiphop_song_list'),
    path('music/pop-songs/', views.pop_song_list, name='pop_song_list'),
    path('music/bollywood-songs/', views.bollywood_song_list, name='bollywood_song_list'),
    path('music/country-songs/', views.country_song_list, name='country_song_list'),
    path('music/classical-songs/', views.classical_song_list, name='classical_song_list'),
    
    path('books/top-books/', views.top_books, name='top_books'),
    path('courses/tech-courses/', views.tech_courses, name='tech_courses'),
    path('courses/language-courses/', views.language_courses, name='language_courses'),
    path('courses/digital-marketing-courses/', views.digital_marketing_courses, name='digital_marketing_courses'),
    path('courses/drop-shipping-courses/', views.drop_shipping_courses, name='drop_shipping_courses'),

    path('hobbies/', views.hobby_list, name='hobby_list'),
    path('relax/', views.relax_list, name='relax_list'),  # Add this line for relax activities
]
