from django.db import models

class ActionMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'action_movies'
        managed = False

    def __str__(self):
        return self.title

class AdventureMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'adventure_movies'
        managed = False

    def __str__(self):
        return self.title

class ThrillerMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'thriller_movies'
        managed = False

    def __str__(self):
        return self.title

class ComedyMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'comedy_movies'
        managed = False

    def __str__(self):
        return self.title

class FantasyMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'fantasy_movies'
        managed = False

    def __str__(self):
        return self.title

class ScienceFictionMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'science_fiction_movies'
        managed = False

    def __str__(self):
        return self.title

class RomanceMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'romance_movies'
        managed = False

    def __str__(self):
        return self.title

class CrimeMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'crime_movies'
        managed = False

    def __str__(self):
        return self.title

class DramaMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'drama_movies'
        managed = False

    def __str__(self):
        return self.title

class HorrorMovie(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    rating = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = 'horror_movies'
        managed = False

    def __str__(self):
        return self.title

class HipHopMusic(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    artist = models.CharField(max_length=255)

    class Meta:
        db_table = 'hiphop_songs'
        managed = False

    def __str__(self):
        return self.title

class PopMusic(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    artist = models.CharField(max_length=255)

    class Meta:
        db_table = 'pop_songs'
        managed = False

    def __str__(self):
        return self.title

class BollywoodMusic(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    artist = models.CharField(max_length=255)

    class Meta:
        db_table = 'bollywood_songs'
        managed = False

    def __str__(self):
        return self.title

class CountryMusic(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    artist = models.CharField(max_length=255)

    class Meta:
        db_table = 'country_songs'
        managed = False

    def __str__(self):
        return self.title

class ClassicalMusic(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    artist = models.CharField(max_length=255)

    class Meta:
        db_table = 'classical_songs'
        managed = False

    def __str__(self):
        return self.title

class ActionGame(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    developer = models.CharField(max_length=255)

    class Meta:
        db_table = 'action_video_games'
        managed = False

    def __str__(self):
        return self.title

class RPGGame(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    developer = models.CharField(max_length=255)

    class Meta:
        db_table = 'rpg_video_games'
        managed = False

    def __str__(self):
        return self.title

class SimulationGame(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    developer = models.CharField(max_length=255)

    class Meta:
        db_table = 'simulation_video_games'
        managed = False

    def __str__(self):
        return self.title

class AdventureGame(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    developer = models.CharField(max_length=255)

    class Meta:
        db_table = 'adventure_video_games'
        managed = False

    def __str__(self):
        return self.title

class SportsGame(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    release_date = models.DateField()
    developer = models.CharField(max_length=255)

    class Meta:
        db_table = 'sports_video_games'
        managed = False

    def __str__(self):
        return self.title

class Book(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    publication_date = models.DateField()

    class Meta:
        db_table = 'books'
        managed = False

    def __str__(self):
        return self.title

class Course(models.Model):
    CATEGORY_CHOICES = [
        ('Tech', 'Tech'),
        ('Language', 'Language'),
        ('Digital Marketing', 'Digital Marketing'),
        ('Drop Shipping', 'Drop Shipping'),
    ]

    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    organization = models.CharField(max_length=255)
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)

    class Meta:
        db_table = 'courses'
        managed = False

    def __str__(self):
        return self.title

class Hobby(models.Model):
    id = models.AutoField(primary_key=True)
    hobby_name = models.CharField(max_length=50)

    class Meta:
        db_table = 'hobbies'
        managed = False

    def __str__(self):
        return self.hobby_name

class Relax(models.Model):
    id = models.AutoField(primary_key=True)
    activity = models.CharField(max_length=50)

    class Meta:
        db_table = 'relax'
        managed = False

    def __str__(self):
        return self.activity
